#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <queue>
#include <unordered_map>
#include <limits>
#include "json.hpp"

using json = nlohmann::json;
using namespace std;

struct SplayNode {
    std::string reg_no;
    std::string name;
    SplayNode* left;
    SplayNode* right;

    SplayNode(const std::string& r, const std::string& n)
        : reg_no(r), name(n), left(nullptr), right(nullptr) {}
};

class SplayTree {
public:
    SplayTree() : root(nullptr) {}

    void insert(const std::string& reg_no, const std::string& name) {
        root = insert(root, reg_no, name);
        root = splay(root, reg_no);
    }

    std::string search(const std::string& reg_no) {
        root = splay(root, reg_no);
        if (root && root->reg_no == reg_no) {
            return "Register Number: " + root->reg_no + ", Name: " + root->name;
        } else {
            return "No such details found";
        }
    }

private:
    SplayNode* root;

    SplayNode* rightRotate(SplayNode* x) {
        SplayNode* y = x->left;
        x->left = y->right;
        y->right = x;
        return y;
    }

    SplayNode* leftRotate(SplayNode* x) {
        SplayNode* y = x->right;
        x->right = y->left;
        y->left = x;
        return y;
    }

    SplayNode* splay(SplayNode* root, const std::string& reg_no) {
        if (!root || root->reg_no == reg_no)
            return root;

        if (root->reg_no > reg_no) {
            if (!root->left) return root;
            if (root->left->reg_no > reg_no) {
                root->left->left = splay(root->left->left, reg_no);
                root = rightRotate(root);
            } else if (root->left->reg_no < reg_no) {
                root->left->right = splay(root->left->right, reg_no);
                if (root->left->right)
                    root->left = leftRotate(root->left);
            }
            return (root->left == nullptr) ? root : rightRotate(root);
        } else {
            if (!root->right) return root;
            if (root->right->reg_no > reg_no) {
                root->right->left = splay(root->right->left, reg_no);
                if (root->right->left)
                    root->right = rightRotate(root->right);
            } else if (root->right->reg_no < reg_no) {
                root->right->right = splay(root->right->right, reg_no);
                root = leftRotate(root);
            }
            return (root->right == nullptr) ? root : leftRotate(root);
        }
    }

    SplayNode* insert(SplayNode* node, const std::string& reg_no, const std::string& name) {
        if (!node) return new SplayNode(reg_no, name);

        if (reg_no < node->reg_no)
            node->left = insert(node->left, reg_no, name);
        else if (reg_no > node->reg_no)
            node->right = insert(node->right, reg_no, name);

        return node;
    }
};

void load_friends_list(std::map<std::string, std::vector<std::string>>& friends_list) {
    std::ifstream file("C:\\xampp\\htdocs\\templates\\friends_list.json");
    if (!file) {
        std::cerr << "Error opening friends list file" << std::endl;
        return;
    }

    json j;
    file >> j;
    friends_list = j.get<std::map<std::string, std::vector<std::string>>>();
    file.close();
}

void display_friends_list(const std::string& register_number, const std::map<std::string, std::vector<std::string>>& friends_list) {
    if (friends_list.find(register_number) != friends_list.end()) {
        std::cout << "Friends list for register number " << register_number << ":\n";
        for (const std::string& friend_number : friends_list.at(register_number)) {
            std::cout << "Friend: " << friend_number << std::endl;
        }
    } else {
        std::cout << "No friends found for register number " << register_number << std::endl;
    }
}

void construct_adjacency_list(const std::map<std::string, std::vector<std::string>>& friends_list) {
    std::cout << "Adjacency List:" << std::endl;
    for (const auto& pair : friends_list) {
        std::cout << pair.first << ": ";
        for (const auto& friend_number : pair.second) {
            std::cout << friend_number << " ";
        }
        std::cout << std::endl;
    }
}

void dijkstra(const std::map<std::string, std::vector<std::string>>& adj_list, const std::string& src, const std::string& dest) {
    std::unordered_map<std::string, int> dist;
    std::unordered_map<std::string, std::string> prev;
    std::priority_queue<std::pair<int, std::string>, std::vector<std::pair<int, std::string>>, std::greater<>> pq;

    for (const auto& pair : adj_list) {
        dist[pair.first] = std::numeric_limits<int>::max();
        prev[pair.first] = "";
    }

    dist[src] = 0;
    pq.push({0, src});

    while (!pq.empty()) {
        std::string u = pq.top().second;
        pq.pop();

        if (u == dest) break;

        for (const std::string& neighbor : adj_list.at(u)) {
            int alt = dist[u] + 1;
            if (alt < dist[neighbor]) {
                dist[neighbor] = alt;
                prev[neighbor] = u;
                pq.push({alt, neighbor});
            }
        }
    }

    if (dist[dest] == std::numeric_limits<int>::max()) {
        std::cout << "No path found from " << src << " to " << dest << std::endl;
        return;
    }

    std::vector<std::string> path;
    for (std::string at = dest; !at.empty(); at = prev[at])
        path.push_back(at);

    std::reverse(path.begin(), path.end());

    std::cout << "Shortest path from " << src << " to " << dest << " is: ";
    for (const std::string& node : path)
        std::cout << node << " ";
    std::cout << "\nRecommendation Level: " << path.size()<< std::endl;  // -1 for source, -1 for destination
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <source_register_number> <destination_register_number>" << std::endl;
        return 1;
    }

    std::string source = argv[1];
    std::string destination = argv[2];
    SplayTree tree;

    // Read data from the file
    std::ifstream file("C:\\xampp\\htdocs\\details_stu.txt");
    if (!file) {
        std::cerr << "Error opening details file" << std::endl;
        return 1;
    }

    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string reg_no, name;
        if (std::getline(iss, reg_no, ',') && std::getline(iss, name)) {
            tree.insert(reg_no, name);
        }
    }
    file.close();

    // Search for the source register number
    std::string result = tree.search(source);
    std::cout << result << std::endl;

    // Load friends list
    std::map<std::string, std::vector<std::string>> friends_list;
    load_friends_list(friends_list);

    // Display friends list
    display_friends_list(source, friends_list);

    // Construct adjacency list
    construct_adjacency_list(friends_list);

    // Find and display shortest path using Dijkstra's algorithm
    dijkstra(friends_list, source, destination);

    return 0;
}
