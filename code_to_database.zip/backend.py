from flask import Flask, request, render_template, jsonify, session, redirect, url_for
import json
import subprocess

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Add a secret key for session management

# Paths to the friends list and details file
friends_list_path = r"C:\\xampp\\htdocs\\templates\\friends_list.json"
details_path = r"C:\\xampp\\htdocs\\details_stu.txt"
executable_path = r"C:\\xampp\\htdocs\\helo.exe"

def is_student_in_details(number):
    with open(details_path, 'r') as f:
        for line in f:
            if line.startswith(number + ','):
                return True
    return False

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        # Add authentication logic here
        session['user'] = username  # Assume username is the register number for simplicity
        return render_template('search.html', user=username)
    return render_template('login.html')

@app.route('/index')
def index():
    return render_template('pindex.html')

@app.route('/searchRegister')
def search_register():
    number = request.args.get('number')
    if is_student_in_details(number):
        return jsonify({"found": True})
    else:
        return jsonify({"found": False})

@app.route('/checkDetails')
def check_details():
    number = request.args.get('number')
    if not is_student_in_details(number):
        return "No such details found", 404

    result = subprocess.run([executable_path, number], capture_output=True, text=True)
    return result.stdout.strip()

@app.route('/showFriends')
def show_friends():
    user = session.get('user')
    if not user:
        return redirect(url_for('login'))

    with open(friends_list_path, 'r') as f:
        friends_list = json.load(f)
    friends = friends_list.get(user, [])
    return jsonify({"friends": friends})

@app.route('/addFriend', methods=['POST'])
def add_friend():
    user = session.get('user')
    if not user:
        return redirect(url_for('login'))

    friend = request.form.get('friend')
    if not is_student_in_details(friend):
        return "The friend is not found in the records.", 404

    with open(friends_list_path, 'r') as f:
        friends_list = json.load(f)

    if user in friends_list:
        if friend not in friends_list[user]:
            friends_list[user].append(friend)
    else:
        friends_list[user] = [friend]

    # Update the friend list file
    with open(friends_list_path, 'w') as f:
        json.dump(friends_list, f)

    return f"Friend {friend} added for register number {user}."

def dijkstra(adj_list, src, dest):
    dist = {node: float('inf') for node in adj_list}
    prev = {node: None for node in adj_list}
    dist[src] = 0
    pq = [(0, src)]

    while pq:
        current_dist, current_node = pq.pop(0)

        if current_dist > dist[current_node]:
            continue

        for neighbor in adj_list[current_node]:
            distance = current_dist + 1  # Assuming unweighted graph
            if distance < dist[neighbor]:
                dist[neighbor] = distance
                prev[neighbor] = current_node
                pq.append((distance, neighbor))
                pq.sort(key=lambda x: x[0])

    path = []
    current = dest
    while current is not None:
        path.insert(0, current)
        current = prev[current]

    if path[0] != src:  # If the source is not in the path, no path found
        return []

    return path

@app.route('/findPath')
def find_path():
    source = session.get('user')
    destination = request.args.get('dest')
    if not source or not destination:
        return "Invalid source or destination", 400

    with open(friends_list_path, 'r') as f:
        friends_list = json.load(f)

    # Construct adjacency list
    adj_list = {user: friends_list.get(user, []) for user in friends_list}

    # Find shortest path using Dijkstra's algorithm
    shortest_path = dijkstra(adj_list, source, destination)

    if not shortest_path:
        return jsonify({"error": "No path found"}), 404

    # Calculate level of connection
    level_of_connection = len(shortest_path) # Subtract 2 for source and destination

    return jsonify({"shortest_path": shortest_path, "level_of_connection": level_of_connection})

if __name__ == '__main__':
    app.run(port=5002,debug=True)
