<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "allocate";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle request action
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['requestId']) && isset($_POST['action'])) {
    $requestId = $_POST['requestId'];
    $action = $_POST['action'];
    $status = ($action == 'accept') ? 1 : 0;

    // Update the status in admin_premium_request table
    $updateSql = "UPDATE admin_premium_request SET status = $status WHERE request_id = $requestId";

    if ($conn->query($updateSql) === TRUE) {
        // If the status is accepted, add the request to student_premium_request table
        if ($status == 1 || $status == 0) {
            $result = $conn->query("SELECT student_register_number FROM admin_premium_request WHERE request_id = $requestId");
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $registerNumber = $row['student_register_number'];

                // Insert into student_premium_request table
                $insertSql = "INSERT INTO student_details_premium (register_number, premium_status) VALUES ('$registerNumber', $status)";
                $conn->query($insertSql);
            }
        }

        // Delete the request from admin_premium_request table
        $deleteSql = "DELETE FROM admin_premium_request WHERE request_id = $requestId";
        $conn->query($deleteSql);

        echo "Request handled successfully.";
    } else {
        echo "Error: " . $updateSql . "<br>" . $conn->error;
    }
}

// Fetch pending requests
$requests = $conn->query("SELECT * FROM admin_premium_request WHERE status='pending'");

// Fetch student premium details if requested
$studentDetails = null;
if (isset($_POST['showStudentDetails'])) {
    $studentDetails = $conn->query("SELECT * FROM student_details_premium");
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Requests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f9;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 18px;
            min-width: 400px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
        }
        table th,
        table td {
            padding: 12px 15px;
            text-align: left;
        }
        table th {
            background-color: #009879;
            color: #ffffff;
        }
        table tr {
            border-bottom: 1px solid #dddddd;
        }
        table tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }
        table tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        table tr:hover {
            background-color: #f1f1f1;
        }
        .action-buttons button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
        }
        .action-buttons button:hover {
            background-color: #0056b3;
        }
        form {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        button {
            padding: 10px;
            background-color: #009879;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #007f65;
        }
    </style>
</head>
<body>
    <h2>Premium Requests</h2>
    <table>
        <thead>
            <tr>
                <th>Request ID</th>
                <th>Student Register Number</th>
                <th>Request Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($requests->num_rows > 0): ?>
                <?php while($row = $requests->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['request_id']; ?></td>
                        <td><?php echo $row['student_register_number']; ?></td>
                        <td><?php echo $row['request_date']; ?></td>
                        <td class="action-buttons">
                            <form method="post" action="admin_premium.php">
                                <input type="hidden" name="requestId" value="<?php echo $row['request_id']; ?>">
                                <button type="submit" name="action" value="accept">Accept</button>
                                <button type="submit" name="action" value="deny">Deny</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">No pending requests</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <form method="post" action="admin_premium.php">
        <button type="submit" name="showStudentDetails">Show Student Premium Details</button>
    </form>

    <?php if ($studentDetails): ?>
        <h2>Student Premium Details</h2>
        <table>
            <thead>
                <tr>
                    <th>Register Number</th>
                    <th>Premium Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($studentDetails->num_rows > 0): ?>
                    <?php while($row = $studentDetails->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['register_number']; ?></td>
                            <td><?php echo $row['premium_status']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="2">No student premium details available</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    <?php endif; ?>
</body>
</html>
