<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "allocate";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $registerNumber = $_POST['registerNumber'];
    $requestDate = date("Y-m-d");

    $sql = "INSERT INTO admin_premium_request (student_register_number, request_date) VALUES ('$registerNumber', '$requestDate')";

    if ($conn->query($sql) === TRUE) {
        echo "<p class='success-message'>Request submitted successfully.</p>";
    } else {
        echo "<p class='error-message'>Error: " . $sql . "<br>" . $conn->error . "</p>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Request</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 10px;
            color: #555;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #5A67D8;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #4C51BF;
        }
        .success-message {
            margin-top: 20px;
            font-size: 18px;
            color: #28a745;
            background-color: #e2e8f0;
            padding: 15px;
            border-radius: 5px;
            width: 100%;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .error-message {
            margin-top: 20px;
            font-size: 18px;
            color: #dc3545;
            background-color: #e2e8f0;
            padding: 15px;
            border-radius: 5px;
            width: 100%;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <h2>Submit Premium Request</h2>
    <form method="post" action="student_premium.php">
        <label for="registerNumber">Register Number:</label>
        <input type="text" id="registerNumber" name="registerNumber" required><br>
        <button type="submit">Submit Request</button>
    </form>
</body>
</html>
