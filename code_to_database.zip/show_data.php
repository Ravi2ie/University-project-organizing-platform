<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Processed Feedback Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f9;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 18px;
            min-width: 400px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
        }
        table th,
        table td {
            padding: 12px 15px;
            text-align: left;
        }
        table th {
            background-color: #009879;
            color: #ffffff;
        }
        table tr {
            border-bottom: 1px solid #dddddd;
        }
        table tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }
        table tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        table tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>
    <h2>Processed Feedback Data</h2>

    <?php
    $file = fopen("C:/Users/bhusb/OneDrive/Documents/project/templates/prior_feed.txt", "r");

    if ($file) {
        echo "<table border='1'>";
        echo "<tr>
                <th>ID</th>
                <th>Register Number</th>
                <th>Feedback Type</th>
                <th>Feedback Text</th>
                <th>Submission Date</th>
                <th>Submission Time</th>
                <th>Seen</th>
                <th>Priority</th>
              </tr>";

        while (($line = fgets($file)) !== false) {
            $data = explode("\t", trim($line));
            echo "<tr>";
            foreach ($data as $index => $cell) {
                if ($index == 7) { // Check if this is the priority column
                    echo "<td>" . "1" . "</td>"; // Convert to integer
                } else {
                    echo "<td>" . htmlspecialchars($cell) . "</td>";
                }
            }
            echo "</tr>";
        }

        echo "</table>";
        fclose($file);
    } else {
        echo "<p>Error opening file.</p>";
    }
    ?>
</body>
</html>
