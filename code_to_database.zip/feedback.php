<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "allocate";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle feedback submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registerNumber']) && isset($_POST['feedbackType']) && isset($_POST['feedbackText'])) {
    $registerNumber = $_POST['registerNumber'];
    $feedbackType = $_POST['feedbackType'];
    $feedbackText = $_POST['feedbackText'];

    // Insert the feedback into the user_feedback table
    $insertSql = "INSERT INTO user_feedback (register_number, feedback_type, feedback_text) VALUES ('$registerNumber', '$feedbackType', '$feedbackText')";

    if ($conn->query($insertSql) === TRUE) {
        echo "Feedback submitted successfully.";
    } else {
        echo "Error: " . $insertSql . "<br>" . $conn->error;
    }
}

// Handle marking feedback as seen
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['markSeenId'])) {
    $markSeenId = $_POST['markSeenId'];

    // Update the seen status in the user_feedback table
    $updateSeenSql = "UPDATE user_feedback SET seen = TRUE WHERE id = $markSeenId";

    if ($conn->query($updateSeenSql) === TRUE) {
        echo "Feedback marked as seen.";
    } else {
        echo "Error: " . $updateSeenSql . "<br>" . $conn->error;
    }
}

// Fetch feedback
$feedbacks = $conn->query("SELECT * FROM user_feedback");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Feedback</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f9;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        label, input, textarea, button {
            display: block;
            width: 100%;
            margin-bottom: 10px;
        }
        input[type="text"], textarea {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            padding: 10px;
            background-color: #009879;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #007f65;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 18px;
            min-width: 400px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
        }
        table th,
        table td {
            padding: 12px 15px;
            text-align: left;
        }
        table th {
            background-color: #009879;
            color: #ffffff;
        }
        table tr {
            border-bottom: 1px solid #dddddd;
        }
        table tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }
        table tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        table tr:hover {
            background-color: #f1f1f1;
        }
        .feedback-seen button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
        }
        .feedback-seen button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h2>Submit Your Feedback</h2>
    <form method="post" action="feedback.php">
        <label for="registerNumber">Register Number:</label>
        <input type="text" id="registerNumber" name="registerNumber" required>

        <label for="feedbackType">Feedback Type:</label>
        <input type="radio" id="help" name="feedbackType" value="help" required>
        <label for="help">Help</label>
        <input type="radio" id="suggestion" name="feedbackType" value="suggestion" required>
        <label for="suggestion">Suggestion</label>

        <label for="feedbackText">Your Feedback:</label>
        <textarea id="feedbackText" name="feedbackText" rows="4" cols="50" required></textarea>

        <button type="submit">Submit</button>
    </form>

    <?php if ($feedbacks && $feedbacks->num_rows > 0): ?>
        <h2>Submitted Feedback</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Register Number</th>
                    <th>Feedback Type</th>
                    <th>Feedback Text</th>
                    <th>Submission Date</th>
                    <th>Seen</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $feedbacks->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['register_number']; ?></td>
                        <td><?php echo $row['feedback_type']; ?></td>
                        <td><?php echo $row['feedback_text']; ?></td>
                        <td><?php echo $row['submission_date']; ?></td>
                        <td class="feedback-seen">
                            <?php if ($row['seen']): ?>
                                Seen
                            <?php else: ?>
                                <form method="post" action="feedback.php">
                                    <input type="hidden" name="markSeenId" value="<?php echo $row['id']; ?>">
                                    <button type="submit">Mark as Seen</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No feedback submitted yet.</p>
    <?php endif; ?>
</body>
</html>
