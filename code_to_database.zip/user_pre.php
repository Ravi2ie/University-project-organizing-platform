<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Copy Database to File</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
        }
        button {
            background-color: #5A67D8;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #4C51BF;
        }
        p {
            margin-top: 20px;
            font-size: 18px;
            color: #555;
            background-color: #e2e8f0;
            padding: 15px;
            border-radius: 5px;
            width: 100%;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <h2>Copy Database to File</h2>
    <?php
    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['copyBtn'])) {
            // Database connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "allocate";

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Query to select relevant data from both tables
            $sql = "SELECT uf.*, sdp.premium_status 
                    FROM user_feedback uf
                    LEFT JOIN student_details_premium sdp ON uf.register_number = sdp.register_number";
            $result = $conn->query($sql);

            // Check if there are rows to fetch
            if ($result->num_rows > 0) {
                // Open a file for writing
                $file = fopen("user_feedback.txt", "w");

                // Loop through each row and write to the file
                while ($row = $result->fetch_assoc()) {
                    // Get all values and add a priority number (for simplicity, using an incrementing counter)
                    $line = implode("\t", $row);
                    fwrite($file, $line . PHP_EOL); // Write to the file
                }

                // Close the file
                fclose($file);

                echo "<p>Database copied to user_feedback.txt successfully.</p>";
            } else {
                echo "<p>No rows found in the user_feedback table.</p>";
            }

            $conn->close();
        }
    }
    ?>

    <form method="post" action="">
        <button type="submit" name="copyBtn">Copy Database</button>
    </form>
</body>
</html>
