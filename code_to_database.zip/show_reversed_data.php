<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Define the path to the reversed loan data file
    $filePath = "C:/Users/bhusb/OneDrive/Documents/project/templates/reverse_project.txt";

    // Check if the file exists and is readable
    if (file_exists($filePath) && is_readable($filePath)) {
        // Open the file for reading
        $file = fopen($filePath, "r");

        // Start the HTML table with CSS styling
        echo "<style>";
        echo "table {";
        echo "    width: 100%;";
        echo "    border-collapse: collapse;";
        echo "    margin-top: 20px;";
        echo "}";
        echo "th, td {";
        echo "    border: 1px solid #ddd;";
        echo "    padding: 8px;";
        echo "}";
        echo "th {";
        echo "    background-color: #f2f2f2;";
        echo "}";
        echo ".available {";
        echo "    color: green;";
        echo "}";
        echo ".unavailable {";
        echo "    color: red;";
        echo "}";
        echo "</style>";

        echo "<table>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>Project Name</th>";
        echo "<th>Project Case</th>";
        echo "<th>Project Level</th>";
        echo "<th>Allocation Status</th>";
        echo "<th>Start Time</th>";
        echo "<th>End Time</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";

        // Read the file line by line
        while (($line = fgets($file)) !== false) {
            // Split the line by commas
            $data = explode(",", $line);

            // Trim whitespace from each data field
            $projectName = trim($data[0]);
            $projectCase = trim($data[1]);
            $projectLevel = trim($data[2]);
            $allocationStatus = trim($data[3]);
            $startTime = trim($data[4]);
            $endTime = trim($data[5]);

            // Determine the CSS class for the allocation status
            $allocationClass = (strcasecmp($allocationStatus, 'Available') == 0) ? 'available' : 'unavailable';

            // Output the data in table rows
            echo "<tr>";
            echo "<td>" . htmlspecialchars($projectName) . "</td>";
            echo "<td>" . htmlspecialchars($projectCase) . "</td>";
            echo "<td>" . htmlspecialchars($projectLevel) . "</td>";
            echo "<td class='$allocationClass'>" . htmlspecialchars($allocationStatus) . "</td>";
            echo "<td>" . htmlspecialchars($startTime) . "</td>";
            echo "<td>" . htmlspecialchars($endTime) . "</td>";
            echo "</tr>";
        }

        // Close the file
        fclose($file);

        // End the HTML table
        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p>Error: Unable to read file.</p>";
    }
}
?>
